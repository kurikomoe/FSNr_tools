# NOTE

To overwrite a epk, just put epk  

`root#data#locale#ck#epk#1jftmqc2rr04kclvl0ql71s2ef.epk`) 

to

`patches\typemoon\fsn2\data\root\data\locale\ck\epk\1jftmqc2rr04kclvl0ql71s2ef.epk`



and start `run.bat`



# ALERT

all save files will also be written to `patches\typemoon\fsn2` , this may broke the steam cloud sync (haven't tested)